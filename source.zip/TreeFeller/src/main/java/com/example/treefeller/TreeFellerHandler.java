package com.example.treefeller;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import net.minecraft.block.Block;
import net.minecraft.block.BlockLog;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.event.world.BlockEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.common.util.FakePlayer;

public class TreeFellerHandler {

    /** Safety limits so a giant structure can't lag the server. */
    private static final int MAX_LOGS = 256;
    private static final int MAX_LEAVES = 2048;
    /** How many blocks away from a log leaves are still removed (vanilla decay range is 4). */
    private static final int LEAF_RANGE = 4;

    @SubscribeEvent
    public void onBlockBreak(BlockEvent.BreakEvent event) {
        World world = event.getWorld();
        if (world.isRemote) return;

        EntityPlayer player = event.getPlayer();
        if (player == null || player instanceof FakePlayer) return;
        if (!player.isSneaking()) return; // must be crouching

        BlockPos origin = event.getPos();
        IBlockState originState = event.getState();
        if (!isLog(originState)) return;

        // Must be the BOTTOM log: no log directly underneath.
        if (isLog(world.getBlockState(origin.down()))) return;

        Set<BlockPos> logs = collectLogs(world, origin, originState);
        logs.remove(origin); // the broken block is handled by vanilla

        Set<BlockPos> leaves = collectLeaves(world, logs, origin);

        // Only treat it as a tree if leaves are attached (avoids wrecking log cabins/piles).
        if (leaves.isEmpty()) return;

        boolean creative = player.capabilities.isCreativeMode;
        boolean toolBroke = false;

        for (BlockPos pos : logs) {
            if (!creative) {
                ItemStack held = player.getHeldItemMainhand();
                if (!held.isEmpty() && held.isItemStackDamageable()) {
                    held.damageItem(1, player);
                    if (held.isEmpty()) toolBroke = true;
                }
            }
            world.destroyBlock(pos, !creative);
            if (toolBroke) break;
        }

        if (toolBroke) return;

        for (BlockPos pos : leaves) {
            world.destroyBlock(pos, !creative);
        }
    }

    private static boolean isLog(IBlockState state) {
        return state.getBlock() instanceof BlockLog;
    }

    private static boolean isLeaves(World world, BlockPos pos) {
        IBlockState state = world.getBlockState(pos);
        return state.getBlock().isLeaves(state, world, pos);
    }

    /** Flood-fill through connected logs of the same wood type (includes diagonals for branches). */
    private Set<BlockPos> collectLogs(World world, BlockPos origin, IBlockState originState) {
        Block block = originState.getBlock();
        int variant = block.getMetaFromState(originState) & 3;

        Set<BlockPos> found = new LinkedHashSet<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        found.add(origin);
        queue.add(origin);

        while (!queue.isEmpty() && found.size() < MAX_LOGS) {
            BlockPos current = queue.poll();
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = 0; dy <= 1; dy++) { // never go below the base
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        BlockPos next = current.add(dx, dy, dz);
                        if (next.getY() < origin.getY() || found.contains(next)) continue;

                        IBlockState s = world.getBlockState(next);
                        if (s.getBlock() == block && (block.getMetaFromState(s) & 3) == variant) {
                            found.add(next);
                            queue.add(next);
                            if (found.size() >= MAX_LOGS) return found;
                        }
                    }
                }
            }
        }
        return found;
    }

    /** Collect leaves within LEAF_RANGE steps of any log in the tree. */
    private Set<BlockPos> collectLeaves(World world, Set<BlockPos> logs, BlockPos origin) {
        Set<BlockPos> result = new LinkedHashSet<>();
        Map<BlockPos, Integer> dist = new HashMap<>();
        Deque<BlockPos> queue = new ArrayDeque<>();
        Set<BlockPos> sources = new HashSet<>(logs);
        sources.add(origin);

        for (BlockPos log : sources) {
            dist.put(log, 0);
            queue.add(log);
        }

        while (!queue.isEmpty() && result.size() < MAX_LEAVES) {
            BlockPos current = queue.poll();
            int d = dist.get(current);
            if (d >= LEAF_RANGE) continue;

            for (EnumFacing facing : EnumFacing.values()) {
                BlockPos next = current.offset(facing);
                if (dist.containsKey(next)) continue;
                if (isLeaves(world, next)) {
                    dist.put(next, d + 1);
                    result.add(next);
                    queue.add(next);
                }
            }
        }
        return result;
    }
}
