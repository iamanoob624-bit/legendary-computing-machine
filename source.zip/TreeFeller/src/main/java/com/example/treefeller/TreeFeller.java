package com.example.treefeller;

import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

@Mod(modid = TreeFeller.MODID, name = TreeFeller.NAME, version = TreeFeller.VERSION, acceptedMinecraftVersions = "[1.12.2]")
public class TreeFeller {
    public static final String MODID = "treefeller";
    public static final String NAME = "Tree Feller";
    public static final String VERSION = "1.0.0";

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(new TreeFellerHandler());
    }
}
