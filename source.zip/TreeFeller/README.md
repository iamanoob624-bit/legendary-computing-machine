# Tree Feller (Forge 1.12.2)

Crouch (sneak) and break the BOTTOM log of a tree -> the whole tree and its leaves break.

## Build
1. Copy the `gradle/` folder, `gradlew` and `gradlew.bat` from the official Forge 1.12.2 MDK into this folder
   (ForgeGradle 2.3 needs Gradle 4.9 and JDK 8).
2. Run: `gradlew setupDecompWorkspace` then `gradlew build`
3. The mod jar is in `build/libs/`. Drop it into your `mods` folder.

## Notes
- Only works when sneaking and breaking a log with no log below it.
- Requires leaves attached to the logs, so log cabins/piles are not affected.
- Tools lose 1 durability per extra log; creative mode takes none.
- Limits (MAX_LOGS, MAX_LEAVES, LEAF_RANGE) are constants in TreeFellerHandler.java.
